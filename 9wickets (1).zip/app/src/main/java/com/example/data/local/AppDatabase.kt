package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.Agent
import com.example.data.model.AppSettings
import com.example.data.model.Site
import com.example.util.SecurityUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Site::class, Agent::class, AppSettings::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun siteDao(): SiteDao
    abstract fun agentDao(): AgentDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ninewickets_db"
                )
                    .addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(db: AppDatabase) {
            val siteDao = db.siteDao()
            val agentDao = db.agentDao()
            val settingsDao = db.settingsDao()

            // 1. Initial 3 Main Site Cards
            val initialSites = listOf(
                Site(
                    name = "DOLLAR SITE",
                    category = "dollar",
                    description = "Visit Dollar Website",
                    url = "https://9wickets.com",
                    iconType = "dollar",
                    displayOrder = 1,
                    active = true
                ),
                Site(
                    name = "বাংলা সাইট",
                    category = "bangla",
                    description = "বাংলা টাকার সাইট",
                    url = "https://9wickets.com/bn",
                    iconType = "bangla",
                    displayOrder = 2,
                    active = true
                ),
                Site(
                    name = "এজেন্ট লিস্ট",
                    category = "agents",
                    description = "সকল ভেরিফাইড এজেন্ট দেখুন",
                    url = "",
                    iconType = "users",
                    displayOrder = 3,
                    active = true
                ),
                Site(
                    name = "LIVE CRICKET SCORE",
                    category = "dollar",
                    description = "Real-time cricket scores & matches",
                    url = "https://9wickets.com/cricket",
                    iconType = "sports",
                    displayOrder = 4,
                    active = true
                ),
                Site(
                    name = "VIP CLUB",
                    category = "bangla",
                    description = "এক্সক্লুসিভ রিওয়ার্ড এবং বোনাস",
                    url = "https://9wickets.com/vip",
                    iconType = "casino",
                    displayOrder = 5,
                    active = true
                )
            )
            siteDao.insertSites(initialSites)

            // 2. Initial Agents
            val initialAgents = listOf(
                Agent(
                    name = "Emran Khan",
                    category = "Admin",
                    agentCode = "9W-001",
                    phone = "+8801711223344",
                    whatsappUrl = "https://wa.me/8801711223344",
                    telegramUrl = "https://t.me/emrankhan9w",
                    displayOrder = 1,
                    active = true,
                    rating = 5.0f,
                    verified = true
                ),
                Agent(
                    name = "Tanvir Ahmed",
                    category = "Sub Admin",
                    agentCode = "9W-002",
                    phone = "+8801822334455",
                    whatsappUrl = "https://wa.me/8801822334455",
                    telegramUrl = "https://t.me/tanvir9w",
                    displayOrder = 2,
                    active = true,
                    rating = 4.9f,
                    verified = true
                ),
                Agent(
                    name = "Shakib Hasan",
                    category = "Super Agent",
                    agentCode = "9W-003",
                    phone = "+8801933445566",
                    whatsappUrl = "https://wa.me/8801933445566",
                    telegramUrl = "https://t.me/shakib9w",
                    displayOrder = 3,
                    active = true,
                    rating = 4.8f,
                    verified = true
                ),
                Agent(
                    name = "Mahmudul Joy",
                    category = "Super Agent",
                    agentCode = "9W-004",
                    phone = "+8801644556677",
                    whatsappUrl = "https://wa.me/8801644556677",
                    telegramUrl = "https://t.me/mahmudul9w",
                    displayOrder = 4,
                    active = true,
                    rating = 4.9f,
                    verified = true
                ),
                Agent(
                    name = "Rakibul Islam",
                    category = "Master Agent",
                    agentCode = "9W-005",
                    phone = "+8801755667788",
                    whatsappUrl = "https://wa.me/8801755667788",
                    telegramUrl = "https://t.me/rakib9w",
                    displayOrder = 5,
                    active = true,
                    rating = 4.7f,
                    verified = true
                ),
                Agent(
                    name = "Fahim Faysal",
                    category = "Master Agent",
                    agentCode = "9W-006",
                    phone = "+8801866778899",
                    whatsappUrl = "https://wa.me/8801866778899",
                    telegramUrl = "https://t.me/fahim9w",
                    displayOrder = 6,
                    active = true,
                    rating = 4.8f,
                    verified = true
                )
            )
            agentDao.insertAgents(initialAgents)

            // 3. Initial Settings
            val initialSettings = listOf(
                AppSettings("brand_name", "9WICKETS"),
                AppSettings("admin_display_name", "EMRAN KHAN"),
                AppSettings("banner_url", ""),
                AppSettings("logo_url", ""),
                AppSettings("whatsapp_url", "https://wa.me/8801711223344"),
                AppSettings("telegram_url", "https://t.me/ninewicketssupport"),
                AppSettings("facebook_url", "https://facebook.com/9wickets.official"),
                AppSettings("facebook_group_url", "https://facebook.com/groups/9wickets.official"),
                AppSettings("support_url", "https://wa.me/8801711223344"),
                AppSettings("announcement_text", "স্বাগতম 9WICKETS অফিসিয়াল পোর্টালে! দ্রুত ডিপোজিট ও উইথড্র সেবা, বিশ্বস্ত অ্যাডমিন EMRAN KHAN।"),
                AppSettings("footer_text", "© 2026 9WICKETS. All Rights Reserved. Managed by EMRAN KHAN."),
                AppSettings("admin_username", "Admin146"),
                AppSettings("admin_password_hash", SecurityUtil.hashPassword("Admin146"))
            )
            settingsDao.insertSettings(initialSettings)
        }
    }
}
