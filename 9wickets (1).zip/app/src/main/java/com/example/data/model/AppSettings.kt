package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey
    val key: String,
    val value: String
)

data class SiteConfig(
    val brandName: String = "9WICKETS",
    val adminDisplayName: String = "EMRAN KHAN",
    val bannerUrl: String = "",
    val logoUrl: String = "",
    val whatsappUrl: String = "https://wa.me/8801700000000",
    val telegramUrl: String = "https://t.me/ninewicketssupport",
    val facebookUrl: String = "https://facebook.com/9wickets",
    val facebookGroupUrl: String = "https://facebook.com/groups/9wickets",
    val supportUrl: String = "https://wa.me/8801700000000",
    val announcementText: String = "স্বাগতম 9WICKETS অফিসিয়াল পোর্টালে! নিরবচ্ছিন্ন ও নিরাপদ অনলাইন সেবা।",
    val footerText: String = "© 2026 9WICKETS. All Rights Reserved. Managed by EMRAN KHAN."
)
