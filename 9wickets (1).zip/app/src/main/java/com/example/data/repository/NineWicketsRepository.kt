package com.example.data.repository

import com.example.data.local.AgentDao
import com.example.data.local.AppDatabase
import com.example.data.local.SettingsDao
import com.example.data.local.SiteDao
import com.example.data.model.Agent
import com.example.data.model.AppSettings
import com.example.data.model.Site
import com.example.data.model.SiteConfig
import com.example.util.SecurityUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class NineWicketsRepository(
    private val database: AppDatabase
) {
    private val siteDao: SiteDao = database.siteDao()
    private val agentDao: AgentDao = database.agentDao()
    private val settingsDao: SettingsDao = database.settingsDao()

    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    init {
        CoroutineScope(Dispatchers.IO).launch {
            ensureDefaults()
        }
    }

    private suspend fun ensureDefaults() {
        val brand = settingsDao.getSettingValue("brand_name")
        if (brand == null) {
            val defaults = listOf(
                AppSettings("brand_name", "9WICKETS"),
                AppSettings("admin_display_name", "EMRAN KHAN"),
                AppSettings("banner_url", ""),
                AppSettings("logo_url", ""),
                AppSettings("whatsapp_url", "https://wa.me/8801711223344"),
                AppSettings("telegram_url", "https://t.me/ninewicketssupport"),
                AppSettings("facebook_url", "https://facebook.com/9wickets.official"),
                AppSettings("facebook_group_url", "https://facebook.com/groups/9wickets.official"),
                AppSettings("support_url", "https://wa.me/8801711223344"),
                AppSettings("announcement_text", "স্বাগতম 9WICKETS অফিসিয়াল পোর্টালে! নিরবচ্ছিন্ন ও নিরাপদ অনলাইন সেবা।"),
                AppSettings("footer_text", "© 2026 9WICKETS. All Rights Reserved. Managed by EMRAN KHAN."),
                AppSettings("admin_username", "Admin146"),
                AppSettings("admin_password_hash", SecurityUtil.hashPassword("Admin146"))
            )
            settingsDao.insertSettings(defaults)
        } else {
            // Guarantee updated Admin146 credentials
            val currentAdmin = settingsDao.getSettingValue("admin_username")
            if (currentAdmin == "admin" || currentAdmin == null) {
                settingsDao.insertSetting(AppSettings("admin_username", "Admin146"))
                settingsDao.insertSetting(AppSettings("admin_password_hash", SecurityUtil.hashPassword("Admin146")))
            }
            if (settingsDao.getSettingValue("facebook_group_url") == null) {
                settingsDao.insertSetting(AppSettings("facebook_group_url", "https://facebook.com/groups/9wickets.official"))
            }
        }
    }

    // Sites
    fun getAllSites(): Flow<List<Site>> = siteDao.getAllSites()
    fun getActiveSites(): Flow<List<Site>> = siteDao.getActiveSites()
    fun getTotalSitesCount(): Flow<Int> = siteDao.getTotalSitesCount()
    fun getActiveSitesCount(): Flow<Int> = siteDao.getActiveSitesCount()

    suspend fun saveSite(site: Site) = withContext(Dispatchers.IO) {
        if (site.id == 0L) {
            siteDao.insertSite(site)
        } else {
            siteDao.updateSite(site)
        }
    }

    suspend fun deleteSite(site: Site) = withContext(Dispatchers.IO) {
        siteDao.deleteSite(site)
    }

    suspend fun toggleSiteStatus(site: Site) = withContext(Dispatchers.IO) {
        siteDao.updateSite(site.copy(active = !site.active))
    }

    // Agents
    fun getAllAgents(): Flow<List<Agent>> = agentDao.getAllAgents()
    fun getActiveAgents(): Flow<List<Agent>> = agentDao.getActiveAgents()
    fun getActiveAgentsByCategory(category: String): Flow<List<Agent>> =
        agentDao.getActiveAgentsByCategory(category)
    fun getTotalAgentsCount(): Flow<Int> = agentDao.getTotalAgentsCount()
    fun getActiveAgentsCount(): Flow<Int> = agentDao.getActiveAgentsCount()

    suspend fun saveAgent(agent: Agent) = withContext(Dispatchers.IO) {
        if (agent.id == 0L) {
            agentDao.insertAgent(agent)
        } else {
            agentDao.updateAgent(agent)
        }
    }

    suspend fun deleteAgent(agent: Agent) = withContext(Dispatchers.IO) {
        agentDao.deleteAgent(agent)
    }

    suspend fun toggleAgentStatus(agent: Agent) = withContext(Dispatchers.IO) {
        agentDao.updateAgent(agent.copy(active = !agent.active))
    }

    // Settings
    val siteConfigFlow: Flow<SiteConfig> = settingsDao.getAllSettings().map { settingsList ->
        val map = settingsList.associate { it.key to it.value }
        SiteConfig(
            brandName = map["brand_name"] ?: "9WICKETS",
            adminDisplayName = map["admin_display_name"] ?: "EMRAN KHAN",
            bannerUrl = map["banner_url"] ?: "",
            logoUrl = map["logo_url"] ?: "",
            whatsappUrl = map["whatsapp_url"] ?: "https://wa.me/8801711223344",
            telegramUrl = map["telegram_url"] ?: "https://t.me/ninewicketssupport",
            facebookUrl = map["facebook_url"] ?: "https://facebook.com/9wickets.official",
            facebookGroupUrl = map["facebook_group_url"] ?: "https://facebook.com/groups/9wickets.official",
            supportUrl = map["support_url"] ?: "https://wa.me/8801711223344",
            announcementText = map["announcement_text"] ?: "স্বাগতম 9WICKETS অফিসিয়াল পোর্টালে!",
            footerText = map["footer_text"] ?: "© 2026 9WICKETS. All Rights Reserved. Managed by EMRAN KHAN."
        )
    }

    suspend fun updateSetting(key: String, value: String) = withContext(Dispatchers.IO) {
        settingsDao.insertSetting(AppSettings(key, value))
    }

    suspend fun updateSettings(entries: Map<String, String>) = withContext(Dispatchers.IO) {
        val list = entries.map { AppSettings(it.key, it.value) }
        settingsDao.insertSettings(list)
    }

    // Authentication
    suspend fun login(usernameInput: String, passwordInput: String): Boolean = withContext(Dispatchers.IO) {
        val storedUsername = settingsDao.getSettingValue("admin_username") ?: "Admin146"
        val storedHash = settingsDao.getSettingValue("admin_password_hash")
            ?: SecurityUtil.hashPassword("Admin146")

        if (usernameInput.trim() == storedUsername && SecurityUtil.verifyPassword(passwordInput, storedHash)) {
            _isAdminLoggedIn.value = true
            true
        } else {
            false
        }
    }

    fun logout() {
        _isAdminLoggedIn.value = false
    }

    suspend fun changeCredentials(
        currentPass: String,
        newUsername: String,
        newPass: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val storedHash = settingsDao.getSettingValue("admin_password_hash")
            ?: SecurityUtil.hashPassword("admin123")

        if (!SecurityUtil.verifyPassword(currentPass, storedHash)) {
            return@withContext Result.failure(Exception("বর্তমান পাসওয়ার্ড সঠিক নয়।"))
        }

        if (newUsername.isBlank()) {
            return@withContext Result.failure(Exception("ইউজারনেম খালি হতে পারে না।"))
        }

        if (newPass.isNotBlank() && newPass.length < 6) {
            return@withContext Result.failure(Exception("নতুন পাসওয়ার্ড ন্যূনতম ৬ অক্ষরের হতে হবে।"))
        }

        settingsDao.insertSetting(AppSettings("admin_username", newUsername.trim()))
        if (newPass.isNotBlank()) {
            settingsDao.insertSetting(
                AppSettings("admin_password_hash", SecurityUtil.hashPassword(newPass))
            )
        }

        Result.success(Unit)
    }
}
