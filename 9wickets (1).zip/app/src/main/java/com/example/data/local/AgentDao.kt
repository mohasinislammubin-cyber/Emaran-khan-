package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Agent
import kotlinx.coroutines.flow.Flow

@Dao
interface AgentDao {
    @Query("SELECT * FROM agents ORDER BY displayOrder ASC, id ASC")
    fun getAllAgents(): Flow<List<Agent>>

    @Query("SELECT * FROM agents WHERE active = 1 ORDER BY displayOrder ASC, id ASC")
    fun getActiveAgents(): Flow<List<Agent>>

    @Query("SELECT * FROM agents WHERE active = 1 AND category = :category ORDER BY displayOrder ASC, id ASC")
    fun getActiveAgentsByCategory(category: String): Flow<List<Agent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAgent(agent: Agent): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAgents(agents: List<Agent>)

    @Update
    suspend fun updateAgent(agent: Agent)

    @Delete
    suspend fun deleteAgent(agent: Agent)

    @Query("SELECT COUNT(*) FROM agents")
    fun getTotalAgentsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM agents WHERE active = 1")
    fun getActiveAgentsCount(): Flow<Int>
}
