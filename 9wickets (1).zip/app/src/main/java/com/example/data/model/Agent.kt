package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "agents")
data class Agent(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String, // "Admin", "Sub Admin", "Super Agent", "Master Agent"
    val phone: String = "",
    val whatsappUrl: String = "",
    val telegramUrl: String = "",
    val profileImageUrl: String = "",
    val agentCode: String = "", // e.g. "9W-001"
    val displayOrder: Int = 0,
    val active: Boolean = true,
    val rating: Float = 5.0f,
    val verified: Boolean = true
)
