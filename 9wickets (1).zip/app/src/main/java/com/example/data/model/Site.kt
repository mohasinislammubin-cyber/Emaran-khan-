package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sites")
data class Site(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String, // "dollar", "bangla", "other"
    val description: String,
    val url: String,
    val iconType: String = "globe", // "dollar", "bangla", "globe", "users", "sports", "casino"
    val iconUrl: String = "", // Optional external/custom image URL
    val displayOrder: Int = 0,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
