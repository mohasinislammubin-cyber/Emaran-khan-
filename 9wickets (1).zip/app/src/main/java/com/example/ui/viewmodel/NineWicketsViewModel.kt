package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.Agent
import com.example.data.model.Site
import com.example.data.model.SiteConfig
import com.example.data.repository.NineWicketsRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    HOME,
    AGENTS,
    ADMIN_LOGIN,
    ADMIN_DASHBOARD
}

enum class AdminTab {
    OVERVIEW,
    SITES,
    AGENTS,
    CONTACTS,
    BANNER_LOGO,
    HOMEPAGE_SETTINGS,
    ACCOUNT,
    FIREBASE_GUIDE
}

class NineWicketsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: NineWicketsRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = NineWicketsRepository(database)
    }

    // Navigation State
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _currentAdminTab = MutableStateFlow(AdminTab.OVERVIEW)
    val currentAdminTab: StateFlow<AdminTab> = _currentAdminTab.asStateFlow()

    // Agent Search & Filter
    private val _agentSearchQuery = MutableStateFlow("")
    val agentSearchQuery: StateFlow<String> = _agentSearchQuery.asStateFlow()

    private val _selectedAgentCategory = MutableStateFlow("All")
    val selectedAgentCategory: StateFlow<String> = _selectedAgentCategory.asStateFlow()

    // Snackbar / Feedback
    private val _snackbarMessage = MutableSharedFlow<String>()
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    // Dialog state for Site editing
    private val _editingSite = MutableStateFlow<Site?>(null)
    val editingSite: StateFlow<Site?> = _editingSite.asStateFlow()
    private val _showSiteDialog = MutableStateFlow(false)
    val showSiteDialog: StateFlow<Boolean> = _showSiteDialog.asStateFlow()

    // Dialog state for Agent editing
    private val _editingAgent = MutableStateFlow<Agent?>(null)
    val editingAgent: StateFlow<Agent?> = _editingAgent.asStateFlow()
    private val _showAgentDialog = MutableStateFlow(false)
    val showAgentDialog: StateFlow<Boolean> = _showAgentDialog.asStateFlow()

    // Repository Flows
    val isAdminLoggedIn: StateFlow<Boolean> = repository.isAdminLoggedIn

    val siteConfig: StateFlow<SiteConfig> = repository.siteConfigFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SiteConfig()
    )

    val activeSites: StateFlow<List<Site>> = repository.getActiveSites().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allSites: StateFlow<List<Site>> = repository.getAllSites().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val activeAgents: StateFlow<List<Agent>> = repository.getActiveAgents().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allAgents: StateFlow<List<Agent>> = repository.getAllAgents().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Filtered active agents for public visitor directory
    val filteredActiveAgents: StateFlow<List<Agent>> = combine(
        activeAgents,
        agentSearchQuery,
        selectedAgentCategory
    ) { agents, query, category ->
        agents.filter { agent ->
            val matchesCategory = (category == "All" || agent.category.equals(category, ignoreCase = true))
            val matchesQuery = query.isBlank() ||
                    agent.name.contains(query, ignoreCase = true) ||
                    agent.category.contains(query, ignoreCase = true) ||
                    agent.phone.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val totalSitesCount: StateFlow<Int> = repository.getTotalSitesCount().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val activeSitesCount: StateFlow<Int> = repository.getActiveSitesCount().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val totalAgentsCount: StateFlow<Int> = repository.getTotalAgentsCount().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val activeAgentsCount: StateFlow<Int> = repository.getActiveAgentsCount().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    // Navigation
    fun navigateTo(screen: AppScreen) {
        if (screen == AppScreen.ADMIN_DASHBOARD && !isAdminLoggedIn.value) {
            _currentScreen.value = AppScreen.ADMIN_LOGIN
        } else {
            _currentScreen.value = screen
        }
    }

    fun setAdminTab(tab: AdminTab) {
        _currentAdminTab.value = tab
    }

    fun setAgentSearchQuery(query: String) {
        _agentSearchQuery.value = query
    }

    fun setAgentCategory(category: String) {
        _selectedAgentCategory.value = category
    }

    // Site Actions
    fun openNewSiteDialog() {
        _editingSite.value = null
        _showSiteDialog.value = true
    }

    fun openEditSiteDialog(site: Site) {
        _editingSite.value = site
        _showSiteDialog.value = true
    }

    fun closeSiteDialog() {
        _showSiteDialog.value = false
        _editingSite.value = null
    }

    fun saveSite(site: Site) {
        viewModelScope.launch {
            repository.saveSite(site)
            _showSiteDialog.value = false
            _editingSite.value = null
            _snackbarMessage.emit("ওয়েবসাইট সফলভাবে সংরক্ষণ করা হয়েছে।")
        }
    }

    fun deleteSite(site: Site) {
        viewModelScope.launch {
            repository.deleteSite(site)
            _snackbarMessage.emit("${site.name} মুছে ফেলা হয়েছে।")
        }
    }

    fun toggleSiteStatus(site: Site) {
        viewModelScope.launch {
            repository.toggleSiteStatus(site)
            val statusText = if (!site.active) "সক্রিয়" else "নিষ্ক্রিয়"
            _snackbarMessage.emit("${site.name} $statusText করা হয়েছে।")
        }
    }

    // Agent Actions
    fun openNewAgentDialog() {
        _editingAgent.value = null
        _showAgentDialog.value = true
    }

    fun openEditAgentDialog(agent: Agent) {
        _editingAgent.value = agent
        _showAgentDialog.value = true
    }

    fun closeAgentDialog() {
        _showAgentDialog.value = false
        _editingAgent.value = null
    }

    fun saveAgent(agent: Agent) {
        viewModelScope.launch {
            repository.saveAgent(agent)
            _showAgentDialog.value = false
            _editingAgent.value = null
            _snackbarMessage.emit("এজেন্ট রেকর্ড সফলভাবে সংরক্ষণ করা হয়েছে।")
        }
    }

    fun deleteAgent(agent: Agent) {
        viewModelScope.launch {
            repository.deleteAgent(agent)
            _snackbarMessage.emit("${agent.name} এজেন্ট তালিকা থেকে সরানো হয়েছে।")
        }
    }

    fun toggleAgentStatus(agent: Agent) {
        viewModelScope.launch {
            repository.toggleAgentStatus(agent)
            val statusText = if (!agent.active) "সক্রিয়" else "নিষ্ক্রিয়"
            _snackbarMessage.emit("${agent.name} $statusText করা হয়েছে।")
        }
    }

    // Settings Updates
    fun updateContactSettings(whatsapp: String, telegram: String, facebook: String, facebookGroup: String, support: String) {
        viewModelScope.launch {
            repository.updateSettings(
                mapOf(
                    "whatsapp_url" to whatsapp.trim(),
                    "telegram_url" to telegram.trim(),
                    "facebook_url" to facebook.trim(),
                    "facebook_group_url" to facebookGroup.trim(),
                    "support_url" to support.trim()
                )
            )
            _snackbarMessage.emit("যোগাযোগ সেটিংস সফলভাবে আপডেট হয়েছে।")
        }
    }

    fun updateBrandingSettings(brandName: String, adminName: String, announcement: String, footer: String) {
        viewModelScope.launch {
            repository.updateSettings(
                mapOf(
                    "brand_name" to brandName.trim(),
                    "admin_display_name" to adminName.trim(),
                    "announcement_text" to announcement.trim(),
                    "footer_text" to footer.trim()
                )
            )
            _snackbarMessage.emit("হোমপেজ ও ব্র্যান্ড সেটিংস আপডেট হয়েছে।")
        }
    }

    fun updateBannerLogoSettings(bannerUrl: String, logoUrl: String) {
        viewModelScope.launch {
            repository.updateSettings(
                mapOf(
                    "banner_url" to bannerUrl.trim(),
                    "logo_url" to logoUrl.trim()
                )
            )
            _snackbarMessage.emit("ব্যানার ও লোগো সেটিংস আপডেট হয়েছে।")
        }
    }

    // Auth
    suspend fun login(user: String, pass: String): Boolean {
        val success = repository.login(user, pass)
        if (success) {
            _currentScreen.value = AppScreen.ADMIN_DASHBOARD
            _snackbarMessage.emit("এডমিন সফলভাবে লগইন করেছেন!")
        } else {
            _snackbarMessage.emit("ইউজারনেম বা পাসওয়ার্ড ভুল হয়েছে।")
        }
        return success
    }

    fun logout() {
        repository.logout()
        _currentScreen.value = AppScreen.HOME
        viewModelScope.launch {
            _snackbarMessage.emit("এডমিন অ্যাকাউন্ট থেকে লগআউট সম্পন্ন হয়েছে।")
        }
    }

    suspend fun changeCredentials(curPass: String, newUser: String, newPass: String): Result<Unit> {
        val result = repository.changeCredentials(curPass, newUser, newPass)
        if (result.isSuccess) {
            _snackbarMessage.emit("এডমিন অ্যাক্সেস তথ্য সফলভাবে পরিবর্তিত হয়েছে!")
        } else {
            _snackbarMessage.emit(result.exceptionOrNull()?.message ?: "ত্রুটি হয়েছে")
        }
        return result
    }
}
