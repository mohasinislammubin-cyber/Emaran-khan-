package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Agent
import com.example.ui.components.CyberConfirmDialog
import com.example.ui.theme.CyberDarkSurface
import com.example.ui.theme.CyberRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgentManageDialog(
    agentToEdit: Agent?,
    onSave: (Agent) -> Unit,
    onDelete: ((Agent) -> Unit)?,
    onDismiss: () -> Unit
) {
    var name by remember(agentToEdit) { mutableStateOf(agentToEdit?.name ?: "") }
    var category by remember(agentToEdit) { mutableStateOf(agentToEdit?.category ?: "Master Agent") }
    var phone by remember(agentToEdit) { mutableStateOf(agentToEdit?.phone ?: "") }
    var agentCode by remember(agentToEdit) { mutableStateOf(agentToEdit?.agentCode ?: "") }
    var whatsappUrl by remember(agentToEdit) { mutableStateOf(agentToEdit?.whatsappUrl ?: "") }
    var telegramUrl by remember(agentToEdit) { mutableStateOf(agentToEdit?.telegramUrl ?: "") }
    var profileImageUrl by remember(agentToEdit) { mutableStateOf(agentToEdit?.profileImageUrl ?: "") }
    var displayOrder by remember(agentToEdit) { mutableIntStateOf(agentToEdit?.displayOrder ?: 1) }
    var active by remember(agentToEdit) { mutableStateOf(agentToEdit?.active ?: true) }

    var categoryDropdownExpanded by remember { mutableStateOf(false) }
    val categories = listOf("Admin", "Sub Admin", "Super Agent", "Master Agent")

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    fun validateAndSave() {
        if (name.isBlank()) {
            errorMessage = "এজেন্টের নাম অবশ্যই পূরণ করতে হবে।"
            return
        }

        if (phone.isBlank() && whatsappUrl.isBlank() && telegramUrl.isBlank()) {
            errorMessage = "কমপক্ষে একটি যোগাযোগের মাধ্যম (ফোন, হোয়াটসঅ্যাপ বা টেলিগ্রাম) প্রদান করুন।"
            return
        }

        // Auto-generate standard whatsapp link if only phone is provided
        val finalWhatsapp = if (whatsappUrl.isBlank() && phone.isNotBlank()) {
            val digits = phone.filter { it.isDigit() }
            if (digits.isNotBlank()) "https://wa.me/$digits" else ""
        } else {
            whatsappUrl.trim()
        }

        val updatedAgent = Agent(
            id = agentToEdit?.id ?: 0L,
            name = name.trim(),
            category = category,
            agentCode = agentCode.trim(),
            phone = phone.trim(),
            whatsappUrl = finalWhatsapp,
            telegramUrl = telegramUrl.trim(),
            profileImageUrl = profileImageUrl.trim(),
            displayOrder = displayOrder,
            active = active,
            rating = agentToEdit?.rating ?: 5.0f,
            verified = true
        )
        onSave(updatedAgent)
    }

    if (showDeleteConfirm && agentToEdit != null) {
        CyberConfirmDialog(
            title = "এজেন্ট ডিলিট করুন",
            message = "আপনি কি নিশ্চিত যে '${agentToEdit.name}' এজেন্টকে তালিকা থেকে মুছে ফেলতে চান?",
            onConfirm = {
                onDelete?.invoke(agentToEdit)
                onDismiss()
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberDarkSurface,
        modifier = Modifier.padding(16.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (agentToEdit != null) "এজেন্ট তথ্য এডিট" else "নতুন এজেন্ট যোগ করুন",
                    color = NeonGreenBright,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                if (agentToEdit != null && onDelete != null) {
                    Button(
                        onClick = { showDeleteConfirm = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                        modifier = Modifier
                            .testTag("delete_agent_btn")
                            .height(34.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "DELETE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = CyberRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                // Name
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorMessage = null
                    },
                    label = { Text("এজেন্টের নাম (Agent Name)") },
                    placeholder = { Text("যেমন: Shakib Hasan") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("agent_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = Color(0xFF2C3E33),
                        focusedLabelColor = NeonGreenBright,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category Selector
                ExposedDropdownMenuBox(
                    expanded = categoryDropdownExpanded,
                    onExpandedChange = { categoryDropdownExpanded = !categoryDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("এজেন্ট পদবী / ক্যাটেগরি") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("agent_category_select"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonGreen,
                            unfocusedBorderColor = Color(0xFF2C3E33),
                            focusedLabelColor = NeonGreenBright,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = categoryDropdownExpanded,
                        onDismissRequest = { categoryDropdownExpanded = false },
                        modifier = Modifier.background(Color(0xFF16221C))
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat, color = TextPrimary, fontWeight = FontWeight.Bold) },
                                onClick = {
                                    category = cat
                                    categoryDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Agent ID
                OutlinedTextField(
                    value = agentCode,
                    onValueChange = { agentCode = it },
                    label = { Text("এজেন্ট আইডি (Agent ID - যেমন: 9W-101)") },
                    placeholder = { Text("9W-101") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("agent_code_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = Color(0xFF2C3E33),
                        focusedLabelColor = NeonGreenBright,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Phone
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("ফোন নম্বর (Contact Number)") },
                    placeholder = { Text("+8801700000000") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("agent_phone_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = Color(0xFF2C3E33),
                        focusedLabelColor = NeonGreenBright,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // WhatsApp Link
                OutlinedTextField(
                    value = whatsappUrl,
                    onValueChange = { whatsappUrl = it },
                    label = { Text("হোয়াটসঅ্যাপ লিংক (WhatsApp Link)") },
                    placeholder = { Text("https://wa.me/8801700000000") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("agent_whatsapp_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = Color(0xFF2C3E33),
                        focusedLabelColor = NeonGreenBright,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Telegram Link
                OutlinedTextField(
                    value = telegramUrl,
                    onValueChange = { telegramUrl = it },
                    label = { Text("টেলিগ্রাম লিংক (Telegram Link)") },
                    placeholder = { Text("https://t.me/username") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("agent_telegram_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = Color(0xFF2C3E33),
                        focusedLabelColor = NeonGreenBright,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Profile Image URL
                OutlinedTextField(
                    value = profileImageUrl,
                    onValueChange = { profileImageUrl = it },
                    label = { Text("প্রোফাইল ছবি লিংক (ঐচ্ছিক)") },
                    placeholder = { Text("https://example.com/avatar.jpg") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("agent_image_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = Color(0xFF2C3E33),
                        focusedLabelColor = NeonGreenBright,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Display Order & Active Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ক্রম নম্বর (Display Order):",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = { if (displayOrder > 1) displayOrder-- },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2822)),
                                modifier = Modifier.size(32.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                            ) {
                                Text("-", color = TextPrimary)
                            }
                            Text(
                                text = " $displayOrder ",
                                color = NeonGreenBright,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            Button(
                                onClick = { displayOrder++ },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2822)),
                                modifier = Modifier.size(32.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                            ) {
                                Text("+", color = TextPrimary)
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "স্ট্যাটাস:",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (active) "সক্রিয়" else "নিষ্ক্রিয়",
                                color = if (active) NeonGreenBright else Color.Gray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = active,
                                onCheckedChange = { active = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = NeonGreenBright,
                                    checkedTrackColor = Color(0xFF0F3D20)
                                )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { validateAndSave() },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                modifier = Modifier.testTag("save_agent_btn"),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color(0xFF00220B),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (agentToEdit != null) "আপডেট করুন (SAVE)" else "সংরক্ষণ করুন (SAVE)",
                    color = Color(0xFF00220B),
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_agent_btn")
            ) {
                Text(text = "বাতিল (CANCEL)", color = TextSecondary)
            }
        }
    )
}
