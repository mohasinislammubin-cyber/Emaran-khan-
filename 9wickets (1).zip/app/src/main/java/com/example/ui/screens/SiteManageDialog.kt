package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Site
import com.example.ui.components.CyberConfirmDialog
import com.example.ui.theme.CyberCardElevated
import com.example.ui.theme.CyberDarkSurface
import com.example.ui.theme.CyberRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SiteManageDialog(
    siteToEdit: Site?,
    onSave: (Site) -> Unit,
    onDelete: ((Site) -> Unit)?,
    onDismiss: () -> Unit
) {
    var name by remember(siteToEdit) { mutableStateOf(siteToEdit?.name ?: "") }
    var category by remember(siteToEdit) { mutableStateOf(siteToEdit?.category ?: "dollar") }
    var description by remember(siteToEdit) { mutableStateOf(siteToEdit?.description ?: "") }
    var url by remember(siteToEdit) { mutableStateOf(siteToEdit?.url ?: "") }
    var iconType by remember(siteToEdit) { mutableStateOf(siteToEdit?.iconType ?: "globe") }
    var displayOrder by remember(siteToEdit) { mutableIntStateOf(siteToEdit?.displayOrder ?: 1) }
    var active by remember(siteToEdit) { mutableStateOf(siteToEdit?.active ?: true) }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val iconOptions = listOf(
        "dollar" to Icons.Default.AttachMoney,
        "bangla" to Icons.Default.Flag,
        "globe" to Icons.Default.Language,
        "users" to Icons.Default.Group,
        "sports" to Icons.Default.SportsCricket,
        "casino" to Icons.Default.Casino
    )

    fun validateAndSave() {
        if (name.isBlank()) {
            errorMessage = "ওয়েবসাইটের নাম অবশ্যই দিতে হবে।"
            return
        }

        if (url.isNotBlank()) {
            val formatted = url.trim()
            if (!formatted.startsWith("http://") && !formatted.startsWith("https://")) {
                errorMessage = "ওয়েবসাইট URL অবশ্যই http:// অথবা https:// দিয়ে শুরু হতে হবে।"
                return
            }
        }

        val updatedSite = Site(
            id = siteToEdit?.id ?: 0L,
            name = name.trim(),
            category = category,
            description = description.trim(),
            url = url.trim(),
            iconType = iconType,
            displayOrder = displayOrder,
            active = active,
            createdAt = siteToEdit?.createdAt ?: System.currentTimeMillis()
        )
        onSave(updatedSite)
    }

    if (showDeleteConfirm && siteToEdit != null) {
        CyberConfirmDialog(
            title = "ওয়েবসাইট ডিলিট করুন",
            message = "আপনি কি নিশ্চিত যে '${siteToEdit.name}' ওয়েবসাইটটি মুছে ফেলতে চান?",
            onConfirm = {
                onDelete?.invoke(siteToEdit)
                onDismiss()
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberDarkSurface,
        modifier = Modifier.padding(16.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (siteToEdit != null) "ওয়েবসাইট এডিট করুন" else "নতুন ওয়েবসাইট যোগ করুন",
                    color = NeonGreenBright,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                if (siteToEdit != null && onDelete != null) {
                    Button(
                        onClick = { showDeleteConfirm = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                        modifier = Modifier
                            .testTag("delete_site_btn")
                            .height(34.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "DELETE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = CyberRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                // Site Name
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorMessage = null
                    },
                    label = { Text("সাইটের নাম (Site Name)") },
                    placeholder = { Text("যেমন: Dollar Site বা নতুন সাইট") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("site_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = Color(0xFF2C3E33),
                        focusedLabelColor = NeonGreenBright,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Site Category Selector
                Text(
                    text = "ক্যাটেগরি নির্বাচন (Category):",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = category == "dollar",
                            onClick = { category = "dollar" },
                            colors = RadioButtonDefaults.colors(selectedColor = NeonGreen)
                        )
                        Text("DOLLAR SITE", color = TextPrimary, fontSize = 12.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = category == "bangla",
                            onClick = { category = "bangla" },
                            colors = RadioButtonDefaults.colors(selectedColor = NeonGreen)
                        )
                        Text("বাংলা সাইট", color = TextPrimary, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Site Description
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("সাইটের বিবরণ (Description)") },
                    placeholder = { Text("যেমন: Visit Dollar Website") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("site_desc_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = Color(0xFF2C3E33),
                        focusedLabelColor = NeonGreenBright,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Website URL
                OutlinedTextField(
                    value = url,
                    onValueChange = {
                        url = it
                        errorMessage = null
                    },
                    label = { Text("ওয়েবসাইট লিংক (Website URL)") },
                    placeholder = { Text("https://9wickets.com") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("site_url_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = Color(0xFF2C3E33),
                        focusedLabelColor = NeonGreenBright,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Icon Picker
                Text(
                    text = "আইকন নির্বাচন করুন (Site Icon):",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    iconOptions.forEach { (type, vector) ->
                        val isSelected = iconType == type
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF0C381E) else Color(0xFF16201B))
                                .border(
                                    width = if (isSelected) 1.5.dp else 0.8.dp,
                                    color = if (isSelected) NeonGreen else Color(0xFF2B3D33),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { iconType = type },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = vector,
                                contentDescription = type,
                                tint = if (isSelected) NeonGreenBright else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Display Order & Active Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ক্রম নম্বর (Display Order):",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = { if (displayOrder > 1) displayOrder-- },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2822)),
                                modifier = Modifier.size(32.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                            ) {
                                Text("-", color = TextPrimary)
                            }
                            Text(
                                text = " $displayOrder ",
                                color = NeonGreenBright,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            Button(
                                onClick = { displayOrder++ },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2822)),
                                modifier = Modifier.size(32.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                            ) {
                                Text("+", color = TextPrimary)
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "সাইট স্ট্যাটাস:",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (active) "সক্রিয় (Active)" else "হাইড (Hidden)",
                                color = if (active) NeonGreenBright else Color.Gray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = active,
                                onCheckedChange = { active = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = NeonGreenBright,
                                    checkedTrackColor = Color(0xFF0F3D20)
                                )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { validateAndSave() },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                modifier = Modifier.testTag("save_site_btn"),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color(0xFF00220B),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (siteToEdit != null) "আপডেট করুন (SAVE)" else "সংরক্ষণ করুন (SAVE)",
                    color = Color(0xFF00220B),
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_site_btn")
            ) {
                Text(text = "বাতিল (CANCEL)", color = TextSecondary)
            }
        }
    )
}
