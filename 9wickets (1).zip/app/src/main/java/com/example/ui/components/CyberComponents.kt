package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberCardBg
import com.example.ui.theme.CyberCardElevated
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDarkSurface
import com.example.ui.theme.CyberGold
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBorder
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.NeonGreenDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CyberCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    glowColor: Color = NeonGreen,
    borderWidth: Dp = 1.2.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val clickableModifier = if (onClick != null) {
        modifier.clickable { onClick() }
    } else {
        modifier
    }

    Card(
        modifier = clickableModifier
            .border(
                border = BorderStroke(borderWidth, glowColor.copy(alpha = 0.65f)),
                shape = shape
            ),
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = CyberCardBg
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        content()
    }
}

@Composable
fun CyberButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "cyber_button",
    icon: (@Composable () -> Unit)? = null,
    enabled: Boolean = true,
    isDestructive: Boolean = false
) {
    val bgBrush = if (isDestructive) {
        Brush.horizontalGradient(listOf(CyberRed, Color(0xFFB30030)))
    } else {
        Brush.horizontalGradient(listOf(NeonGreenBright, NeonGreenDark))
    }

    val contentColor = if (isDestructive) Color.White else Color(0xFF00220B)

    Button(
        onClick = onClick,
        modifier = modifier
            .testTag(testTag)
            .height(48.dp),
        enabled = enabled,
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isDestructive) CyberRed else NeonGreen,
            contentColor = contentColor,
            disabledContainerColor = Color(0xFF233029),
            disabledContentColor = TextMuted
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                icon()
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun CyberOutlinedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "cyber_outlined_button",
    icon: (@Composable () -> Unit)? = null,
    borderColor: Color = NeonGreen,
    contentColor: Color = NeonGreen
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .testTag(testTag)
            .height(44.dp),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.2.dp, borderColor),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = contentColor
        ),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                icon()
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = text,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun CyberBadge(
    text: String,
    category: String = "general",
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, borderCol) = when (category.lowercase()) {
        "admin" -> Triple(CyberGold.copy(alpha = 0.2f), CyberGold, CyberGold)
        "sub admin" -> Triple(CyberPurple.copy(alpha = 0.2f), Color(0xFFDF95FF), CyberPurple)
        "super agent" -> Triple(CyberCyan.copy(alpha = 0.2f), CyberCyan, CyberCyan)
        "master agent" -> Triple(NeonGreen.copy(alpha = 0.2f), NeonGreenBright, NeonGreen)
        "active" -> Triple(NeonGreen.copy(alpha = 0.2f), NeonGreenBright, NeonGreen)
        "inactive" -> Triple(Color(0xFF333333), TextMuted, Color(0xFF555555))
        "dollar" -> Triple(CyberCyan.copy(alpha = 0.15f), CyberCyan, CyberCyan)
        "bangla" -> Triple(NeonGreen.copy(alpha = 0.15f), NeonGreenBright, NeonGreen)
        else -> Triple(Color(0xFF1E2B25), TextSecondary, Color(0xFF2F453B))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(0.8.dp, borderCol.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = text.uppercase(),
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            color = textColor,
            letterSpacing = 0.6.sp
        )
    }
}

@Composable
fun CircuitBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.12f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "circuit_glow"
    )

    Box(
        modifier = modifier
            .background(CyberBlack)
            .drawBehind {
                val lineColor = Color(0xFF00FF66).copy(alpha = pulseAlpha)
                val w = size.width
                val h = size.height
                // Subtle cyber grid lines
                drawLine(
                    color = lineColor,
                    start = Offset(0f, 60f),
                    end = Offset(w * 0.35f, 60f),
                    strokeWidth = 1.5f
                )
                drawLine(
                    color = lineColor,
                    start = Offset(w * 0.35f, 60f),
                    end = Offset(w * 0.45f, 120f),
                    strokeWidth = 1.5f
                )
                drawLine(
                    color = lineColor,
                    start = Offset(w * 0.45f, 120f),
                    end = Offset(w, 120f),
                    strokeWidth = 1.5f
                )
            }
    ) {
        content()
    }
}

@Composable
fun CyberConfirmDialog(
    title: String,
    message: String,
    confirmText: String = "ডিলিট করুন",
    cancelText: String = "বাতিল",
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberCardElevated,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = CyberRed,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Text(
                text = message,
                color = TextSecondary,
                fontSize = 14.sp
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(text = confirmText, color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = cancelText, color = TextSecondary)
            }
        }
    )
}
