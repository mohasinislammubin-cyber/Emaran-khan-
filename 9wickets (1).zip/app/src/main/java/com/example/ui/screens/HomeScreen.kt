package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Facebook
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.Site
import com.example.data.model.SiteConfig
import com.example.ui.components.CircuitBackground
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberButton
import com.example.ui.components.CyberCard
import com.example.ui.components.FloatingSupportButton
import com.example.ui.components.HeaderComponent
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberCardBg
import com.example.ui.theme.CyberCardElevated
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDarkSurface
import com.example.ui.theme.CyberGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBorder
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.NeonGreenDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.IntentUtil

@Composable
fun HomeScreen(
    siteConfig: SiteConfig,
    activeSites: List<Site>,
    activeAgentsCount: Int,
    isAdminLoggedIn: Boolean,
    onNavigateToAgents: () -> Unit,
    onAdminClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Extract Main Site 1 & 2 from the database (or match by category / name)
    val dollarSite = activeSites.firstOrNull {
        it.category.equals("dollar", ignoreCase = true) || it.name.contains("DOLLAR", ignoreCase = true)
    } ?: activeSites.firstOrNull()

    val banglaSite = activeSites.firstOrNull {
        it.category.equals("bangla", ignoreCase = true) || it.name.contains("বাংলা", ignoreCase = true)
    } ?: activeSites.getOrNull(1)

    // Other dynamic site cards to display (excluding the main cards to prevent duplication)
    val otherSites = activeSites.filter { it.id != dollarSite?.id && it.id != banglaSite?.id }

    CircuitBackground(modifier = modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 700.dp),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                // 1. Header with 9WICKETS and ADMIN: EMRAN KHAN
                item {
                    HeaderComponent(
                        brandName = siteConfig.brandName,
                        adminDisplayName = siteConfig.adminDisplayName,
                        logoUrl = siteConfig.logoUrl,
                        isAdminLoggedIn = isAdminLoggedIn,
                        onAdminClick = onAdminClick,
                        announcementText = siteConfig.announcementText
                    )
                }

                // 2. Cyber Hero Banner
                item {
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.2.dp, NeonGreenBorder.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                    ) {
                        if (siteConfig.bannerUrl.isNotBlank()) {
                            AsyncImage(
                                model = siteConfig.bannerUrl,
                                contentDescription = "Hero Banner",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.banner_ninewickets),
                                contentDescription = "9WICKETS Cyber Gaming Banner",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f),
                                contentScale = ContentScale.Crop
                            )
                        }

                        // Gradient shadow overlay
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            Color(0xBB080D0B),
                                            Color(0xF0080D0B)
                                        )
                                    )
                                )
                        )

                        // Banner floating badge
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = NeonGreenBright,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "OFFICIAL VERIFIED PORTAL • 24/7 ACTIVE",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }

                // 3. Section Title: MAIN DESTINATIONS
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(4.dp, 16.dp)
                                    .background(NeonGreenBright, RoundedCornerShape(2.dp))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "প্রধান সার্ভিস লিংক",
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Text(
                            text = "SECURE & FAST",
                            color = NeonGreenBright,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // 4. THE THREE MAIN CARDS
                // CARD 1: DOLLAR SITE
                item {
                    MainServiceCard(
                        title = dollarSite?.name ?: "DOLLAR SITE",
                        subtitle = dollarSite?.description ?: "Visit Dollar Website",
                        icon = Icons.Default.AttachMoney,
                        accentColor = CyberCyan,
                        buttonText = "ভিজিট করুন (VISIT)",
                        testTag = "card_dollar_site",
                        onClick = {
                            val url = dollarSite?.url.orEmpty()
                            IntentUtil.openUrl(context, url)
                        }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // CARD 2: বাংলা সাইট
                item {
                    MainServiceCard(
                        title = banglaSite?.name ?: "বাংলা সাইট",
                        subtitle = banglaSite?.description ?: "বাংলা টাকার সাইট",
                        icon = Icons.Default.Flag,
                        accentColor = NeonGreenBright,
                        buttonText = "ভিজিট করুন (VISIT)",
                        testTag = "card_bangla_site",
                        onClick = {
                            val url = banglaSite?.url.orEmpty()
                            IntentUtil.openUrl(context, url)
                        }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // CARD 3: এজেন্ট লিস্ট
                item {
                    MainServiceCard(
                        title = "এজেন্ট লিস্ট",
                        subtitle = "সকল এজেন্ট দেখুন ($activeAgentsCount জন ভেরিফাইড এজেন্ট)",
                        icon = Icons.Default.Group,
                        accentColor = CyberGold,
                        buttonText = "এজেন্ট তালিকা দেখুন",
                        testTag = "card_agent_list",
                        onClick = onNavigateToAgents
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                }

                // 5. Dynamic Additional Sites Section (if configured by admin)
                if (otherSites.isNotEmpty()) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(4.dp, 16.dp)
                                    .background(CyberCyan, RoundedCornerShape(2.dp))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "অন্যান্য সাইট ও লিংকসমূহ",
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    items(otherSites, key = { it.id }) { site ->
                        DynamicSiteCard(
                            site = site,
                            onClick = {
                                IntentUtil.openUrl(context, site.url)
                            }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }

                // 6. CONTACT AND CUSTOMER SUPPORT SECTION
                item {
                    Spacer(modifier = Modifier.height(18.dp))
                    ContactSection(
                        siteConfig = siteConfig,
                        context = context
                    )
                }

                // 7. Footer Section
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = siteConfig.brandName,
                            color = NeonGreenBright,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Admin: ${siteConfig.adminDisplayName}",
                            color = CyberGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = siteConfig.footerText,
                            color = TextMuted,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Fixed Floating Customer Support Button in Bottom-Right
            FloatingSupportButton(
                supportUrl = siteConfig.supportUrl,
                onClick = {
                    IntentUtil.openUrl(context, siteConfig.supportUrl)
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 16.dp, bottom = 20.dp)
            )
        }
    }
}

@Composable
private fun MainServiceCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    buttonText: String,
    testTag: String,
    onClick: () -> Unit
) {
    CyberCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .testTag(testTag),
        glowColor = accentColor,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Icon
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor.copy(alpha = 0.15f))
                    .border(1.2.dp, accentColor.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Title & Subtitle
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = subtitle,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Action Button
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = if (accentColor == CyberGold || accentColor == NeonGreenBright) Color(0xFF00220B) else Color.Black
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = buttonText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun DynamicSiteCard(
    site: Site,
    onClick: () -> Unit
) {
    val icon = when (site.iconType.lowercase()) {
        "dollar" -> Icons.Default.AttachMoney
        "bangla" -> Icons.Default.Flag
        "sports" -> Icons.Default.SportsCricket
        "casino" -> Icons.Default.Casino
        "users" -> Icons.Default.Group
        else -> Icons.Default.Language
    }

    val glowColor = if (site.category == "dollar") CyberCyan else NeonGreen

    CyberCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        glowColor = glowColor,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(glowColor.copy(alpha = 0.15f))
                    .border(1.dp, glowColor.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = site.name,
                    tint = glowColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = site.name,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    CyberBadge(text = site.category, category = site.category)
                }
                if (site.description.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = site.description,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                contentDescription = "Open",
                tint = glowColor,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ContactSection(
    siteConfig: SiteConfig,
    context: Context
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CyberDarkSurface)
            .border(1.dp, Color(0xFF1B2C23), RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Text(
            text = "যোগাযোগ ও কাস্টমার সাপোর্ট",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "যেকোনো সাহায্য বা তথ্যের জন্য সরাসরি আমাদের সাথে যোগাযোগ করুন।",
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(14.dp))

        // Contact buttons row (horizontal scrollable to accommodate WhatsApp, Telegram, FB Page, FB Group, Support)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (siteConfig.whatsappUrl.isNotBlank()) {
                ContactButton(
                    label = "WhatsApp",
                    icon = Icons.Default.Chat,
                    color = Color(0xFF25D366),
                    modifier = Modifier.width(84.dp),
                    onClick = { IntentUtil.openUrl(context, siteConfig.whatsappUrl) }
                )
            }

            if (siteConfig.telegramUrl.isNotBlank()) {
                ContactButton(
                    label = "Telegram",
                    icon = Icons.Default.Send,
                    color = Color(0xFF229ED9),
                    modifier = Modifier.width(84.dp),
                    onClick = { IntentUtil.openUrl(context, siteConfig.telegramUrl) }
                )
            }

            if (siteConfig.facebookUrl.isNotBlank()) {
                ContactButton(
                    label = "Facebook",
                    icon = Icons.Default.Facebook,
                    color = Color(0xFF1877F2),
                    modifier = Modifier.width(84.dp),
                    onClick = { IntentUtil.openUrl(context, siteConfig.facebookUrl) }
                )
            }

            if (siteConfig.facebookGroupUrl.isNotBlank()) {
                ContactButton(
                    label = "FB Group",
                    icon = Icons.Default.Group,
                    color = Color(0xFF2E89FF),
                    modifier = Modifier.width(84.dp),
                    onClick = { IntentUtil.openUrl(context, siteConfig.facebookGroupUrl) }
                )
            }

            if (siteConfig.supportUrl.isNotBlank()) {
                ContactButton(
                    label = "Support",
                    icon = Icons.Default.SupportAgent,
                    color = NeonGreenBright,
                    modifier = Modifier.width(84.dp),
                    onClick = { IntentUtil.openUrl(context, siteConfig.supportUrl) }
                )
            }
        }
    }
}

@Composable
private fun ContactButton(
    label: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                color = TextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
