package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.Agent
import com.example.data.model.Site
import com.example.data.model.SiteConfig
import com.example.ui.components.CircuitBackground
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberButton
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberConfirmDialog
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberCardBg
import com.example.ui.theme.CyberCardElevated
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDarkSurface
import com.example.ui.theme.CyberGold
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AdminTab
import kotlinx.coroutines.launch

@Composable
fun AdminDashboardScreen(
    currentTab: AdminTab,
    onTabSelected: (AdminTab) -> Unit,
    siteConfig: SiteConfig,
    sites: List<Site>,
    agents: List<Agent>,
    totalSitesCount: Int,
    activeSitesCount: Int,
    totalAgentsCount: Int,
    activeAgentsCount: Int,
    onAddSiteClick: () -> Unit,
    onEditSiteClick: (Site) -> Unit,
    onDeleteSiteClick: (Site) -> Unit,
    onToggleSiteStatus: (Site) -> Unit,
    onAddAgentClick: () -> Unit,
    onEditAgentClick: (Agent) -> Unit,
    onDeleteAgentClick: (Agent) -> Unit,
    onToggleAgentStatus: (Agent) -> Unit,
    onUpdateContacts: (String, String, String, String, String) -> Unit,
    onUpdateBranding: (String, String, String, String) -> Unit,
    onUpdateBannerLogo: (String, String) -> Unit,
    onChangeCredentials: suspend (String, String, String) -> Result<Unit>,
    onPreviewHome: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    CircuitBackground(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 800.dp)
        ) {
            // Top Bar
            Surface(
                color = CyberDarkSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        NeonGreen.copy(alpha = 0.5f),
                        RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
                    ),
                shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF0F261B))
                                .border(1.dp, NeonGreen, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = NeonGreenBright,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ADMIN PANEL",
                                color = NeonGreenBright,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "ADMIN: ${siteConfig.adminDisplayName}",
                                color = CyberGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Home Preview button
                        IconButton(
                            onClick = onPreviewHome,
                            modifier = Modifier.testTag("admin_home_preview_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "View Homepage",
                                tint = CyberCyan
                            )
                        }

                        // Logout button
                        Button(
                            onClick = onLogout,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E151A)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .testTag("admin_logout_btn")
                                .height(36.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                contentDescription = "Logout",
                                tint = CyberRed,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "LOGOUT", color = CyberRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Navigation Tabs Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AdminTabItem("ওভারভিউ", AdminTab.OVERVIEW, currentTab, onTabSelected)
                AdminTabItem("ওয়েবসাইট", AdminTab.SITES, currentTab, onTabSelected)
                AdminTabItem("এজেন্ট", AdminTab.AGENTS, currentTab, onTabSelected)
                AdminTabItem("যোগাযোগ", AdminTab.CONTACTS, currentTab, onTabSelected)
                AdminTabItem("ব্যানার/লোগো", AdminTab.BANNER_LOGO, currentTab, onTabSelected)
                AdminTabItem("হোমপেজ", AdminTab.HOMEPAGE_SETTINGS, currentTab, onTabSelected)
                AdminTabItem("অ্যাকাউন্ট", AdminTab.ACCOUNT, currentTab, onTabSelected)
                AdminTabItem("ফায়ারবেস গাইড", AdminTab.FIREBASE_GUIDE, currentTab, onTabSelected)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tab Content
            Box(modifier = Modifier.fillMaxSize()) {
                when (currentTab) {
                    AdminTab.OVERVIEW -> OverviewTab(
                        totalSites = totalSitesCount,
                        activeSites = activeSitesCount,
                        totalAgents = totalAgentsCount,
                        activeAgents = activeAgentsCount,
                        onAddSite = onAddSiteClick,
                        onAddAgent = onAddAgentClick,
                        onPreviewHome = onPreviewHome
                    )

                    AdminTab.SITES -> SitesTab(
                        sites = sites,
                        onAddSite = onAddSiteClick,
                        onEditSite = onEditSiteClick,
                        onDeleteSite = onDeleteSiteClick,
                        onToggleSite = onToggleSiteStatus
                    )

                    AdminTab.AGENTS -> AgentsTab(
                        agents = agents,
                        onAddAgent = onAddAgentClick,
                        onEditAgent = onEditAgentClick,
                        onDeleteAgent = onDeleteAgentClick,
                        onToggleAgent = onToggleAgentStatus
                    )

                    AdminTab.CONTACTS -> ContactsTab(
                        siteConfig = siteConfig,
                        onSave = onUpdateContacts
                    )

                    AdminTab.BANNER_LOGO -> BannerLogoTab(
                        siteConfig = siteConfig,
                        onSave = onUpdateBannerLogo
                    )

                    AdminTab.HOMEPAGE_SETTINGS -> HomepageSettingsTab(
                        siteConfig = siteConfig,
                        onSave = onUpdateBranding
                    )

                    AdminTab.ACCOUNT -> AccountTab(
                        onChangeCredentials = onChangeCredentials
                    )

                    AdminTab.FIREBASE_GUIDE -> FirebaseGuideTab()
                }
            }
        }
    }
}

@Composable
private fun AdminTabItem(
    title: String,
    tab: AdminTab,
    currentTab: AdminTab,
    onTabSelected: (AdminTab) -> Unit
) {
    val isSelected = currentTab == tab
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) NeonGreen else Color(0xFF141F1A))
            .border(
                1.dp,
                if (isSelected) NeonGreenBright else Color(0xFF263A2F),
                RoundedCornerShape(8.dp)
            )
            .clickable { onTabSelected(tab) }
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(
            text = title,
            color = if (isSelected) Color(0xFF00220B) else TextSecondary,
            fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold,
            fontSize = 12.sp
        )
    }
}

// 1. Overview Tab
@Composable
private fun OverviewTab(
    totalSites: Int,
    activeSites: Int,
    totalAgents: Int,
    activeAgents: Int,
    onAddSite: () -> Unit,
    onAddAgent: () -> Unit,
    onPreviewHome: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "ড্যাশবোর্ড ওভারভিউ (DASHBOARD STATS)",
            color = NeonGreenBright,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        // 4 Stat Cards in 2x2 grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard(
                title = "মোট সাইট",
                value = "$totalSites",
                accentColor = CyberCyan,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "সক্রিয় সাইট",
                value = "$activeSites",
                accentColor = NeonGreenBright,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard(
                title = "মোট এজেন্ট",
                value = "$totalAgents",
                accentColor = CyberGold,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "সক্রিয় এজেন্ট",
                value = "$activeAgents",
                accentColor = CyberPurple,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Quick Actions
        Text(
            text = "দ্রুত অ্যাকশন (QUICK ACTIONS)",
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CyberButton(
                text = "+ নতুন সাইট",
                onClick = onAddSite,
                modifier = Modifier.weight(1f),
                testTag = "overview_add_site_btn"
            )
            CyberButton(
                text = "+ নতুন এজেন্ট",
                onClick = onAddAgent,
                modifier = Modifier.weight(1f),
                testTag = "overview_add_agent_btn"
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Database status banner
        CyberCard(
            modifier = Modifier.fillMaxWidth(),
            glowColor = NeonGreen
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CloudDone,
                    contentDescription = null,
                    tint = NeonGreenBright,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "ডাটাবেস ও স্টোরেজ স্ট্যাটাস",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "অন-ডিভাইস রিয়েল ডাটাবেস (SQLite/Room) সম্পূর্ণ সক্রিয় ও পারসিস্টেন্ট। পরিবর্তন সরাসরি হোমপেজে প্রদর্শিত হবে।",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    CyberCard(
        modifier = modifier,
        glowColor = accentColor,
        borderWidth = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Text(
                text = title,
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                color = accentColor,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

// 2. Sites Management Tab
@Composable
private fun SitesTab(
    sites: List<Site>,
    onAddSite: () -> Unit,
    onEditSite: (Site) -> Unit,
    onDeleteSite: (Site) -> Unit,
    onToggleSite: (Site) -> Unit
) {
    var siteToDelete by remember { mutableStateOf<Site?>(null) }

    if (siteToDelete != null) {
        CyberConfirmDialog(
            title = "ওয়েবসাইট মুছে ফেলুন",
            message = "আপনি কি নিশ্চিত যে '${siteToDelete?.name}' সাইটটি ডিলিট করতে চান?",
            onConfirm = {
                siteToDelete?.let { onDeleteSite(it) }
                siteToDelete = null
            },
            onDismiss = { siteToDelete = null }
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ওয়েবসাইট তালিকা (${sites.size})",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )

            Button(
                onClick = onAddSite,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                modifier = Modifier
                    .testTag("admin_add_site_btn")
                    .height(36.dp),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = Color(0xFF00220B),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "নতুন সাইট যোগ",
                    color = Color(0xFF00220B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(sites, key = { it.id }) { site ->
                CyberCard(
                    modifier = Modifier.fillMaxWidth(),
                    glowColor = if (site.active) NeonGreen else Color.DarkGray
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = site.name,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    CyberBadge(text = site.category, category = site.category)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (site.url.isNotBlank()) site.url else "লিংক কনফিগার করা হয়নি",
                                    color = if (site.url.isNotBlank()) CyberCyan else CyberRed,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(
                                    checked = site.active,
                                    onCheckedChange = { onToggleSite(site) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = NeonGreenBright,
                                        checkedTrackColor = Color(0xFF0E3D20)
                                    )
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(onClick = { onEditSite(site) }) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit",
                                        tint = NeonGreenBright
                                    )
                                }
                                IconButton(onClick = { siteToDelete = site }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = CyberRed
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 3. Agents Management Tab
@Composable
private fun AgentsTab(
    agents: List<Agent>,
    onAddAgent: () -> Unit,
    onEditAgent: (Agent) -> Unit,
    onDeleteAgent: (Agent) -> Unit,
    onToggleAgent: (Agent) -> Unit
) {
    var agentToDelete by remember { mutableStateOf<Agent?>(null) }

    if (agentToDelete != null) {
        CyberConfirmDialog(
            title = "এজেন্ট মুছে ফেলুন",
            message = "আপনি কি নিশ্চিত যে '${agentToDelete?.name}' এজেন্ট ডিলিট করতে চান?",
            onConfirm = {
                agentToDelete?.let { onDeleteAgent(it) }
                agentToDelete = null
            },
            onDismiss = { agentToDelete = null }
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "এজেন্ট তালিকা (${agents.size})",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )

            Button(
                onClick = onAddAgent,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                modifier = Modifier
                    .testTag("admin_add_agent_btn")
                    .height(36.dp),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = Color(0xFF00220B),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "নতুন এজেন্ট যোগ",
                    color = Color(0xFF00220B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(agents, key = { it.id }) { agent ->
                CyberCard(
                    modifier = Modifier.fillMaxWidth(),
                    glowColor = if (agent.active) NeonGreen else Color.DarkGray
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = agent.name,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                CyberBadge(text = agent.category, category = agent.category)
                                if (agent.agentCode.isNotBlank()) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "[${agent.agentCode}]",
                                        color = CyberCyan,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                            val phoneDisplay = if (agent.phone.isNotBlank()) agent.phone else "N/A"
                            Text(
                                text = "ফোন: $phoneDisplay",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(
                                checked = agent.active,
                                onCheckedChange = { onToggleAgent(agent) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = NeonGreenBright,
                                    checkedTrackColor = Color(0xFF0E3D20)
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            IconButton(onClick = { onEditAgent(agent) }) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit",
                                    tint = NeonGreenBright
                                )
                            }
                            IconButton(onClick = { agentToDelete = agent }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete",
                                    tint = CyberRed
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. Contact Settings Tab
@Composable
private fun ContactsTab(
    siteConfig: SiteConfig,
    onSave: (String, String, String, String, String) -> Unit
) {
    var whatsapp by remember(siteConfig) { mutableStateOf(siteConfig.whatsappUrl) }
    var telegram by remember(siteConfig) { mutableStateOf(siteConfig.telegramUrl) }
    var facebook by remember(siteConfig) { mutableStateOf(siteConfig.facebookUrl) }
    var facebookGroup by remember(siteConfig) { mutableStateOf(siteConfig.facebookGroupUrl) }
    var support by remember(siteConfig) { mutableStateOf(siteConfig.supportUrl) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "যোগাযোগ ও কাস্টমার সাপোর্ট লিংক কনফিগারেশন",
            color = NeonGreenBright,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "যে লিংকটি খালি রাখা হবে হোমপেজে তার বাটন স্বয়ংক্রিয়ভাবে হাইড থাকবে।",
            color = TextSecondary,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = whatsapp,
            onValueChange = { whatsapp = it },
            label = { Text("WhatsApp URL / Link") },
            placeholder = { Text("https://wa.me/8801700000000") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_whatsapp_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = telegram,
            onValueChange = { telegram = it },
            label = { Text("Telegram URL / Link") },
            placeholder = { Text("https://t.me/ninewicketssupport") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_telegram_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = facebook,
            onValueChange = { facebook = it },
            label = { Text("Facebook URL / Page Link (ফেসবুক পেজ লিংক)") },
            placeholder = { Text("https://facebook.com/9wickets") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_facebook_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = facebookGroup,
            onValueChange = { facebookGroup = it },
            label = { Text("Facebook Group Link (ফেসবুক গ্রুপ লিংক)") },
            placeholder = { Text("https://facebook.com/groups/9wickets") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_facebook_group_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = support,
            onValueChange = { support = it },
            label = { Text("Customer Support URL (Floating Button)") },
            placeholder = { Text("https://wa.me/8801700000000") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_support_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        CyberButton(
            text = "সংরক্ষণ করুন (SAVE SETTINGS)",
            onClick = { onSave(whatsapp, telegram, facebook, facebookGroup, support) },
            modifier = Modifier.fillMaxWidth(),
            testTag = "admin_save_contacts_btn"
        )
    }
}

// 5. Banner & Logo Settings Tab
@Composable
private fun BannerLogoTab(
    siteConfig: SiteConfig,
    onSave: (String, String) -> Unit
) {
    var bannerUrl by remember(siteConfig) { mutableStateOf(siteConfig.bannerUrl) }
    var logoUrl by remember(siteConfig) { mutableStateOf(siteConfig.logoUrl) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "লোগো এবং ব্যানার কাস্টমাইজেশন",
            color = NeonGreenBright,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(14.dp))

        // Banner Preview
        Text(
            text = "বর্তমান ব্যানার প্রিভিউ:",
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, NeonGreen, RoundedCornerShape(12.dp))
        ) {
            if (bannerUrl.isNotBlank()) {
                AsyncImage(
                    model = bannerUrl,
                    contentDescription = "Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Image(
                    painter = painterResource(id = R.drawable.banner_ninewickets),
                    contentDescription = "Default Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = bannerUrl,
            onValueChange = { bannerUrl = it },
            label = { Text("ব্যানার ইমেজ URL (খালি রাখলে ডিফল্ট ব্যানার দেখাবে)") },
            placeholder = { Text("https://example.com/banner.jpg") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Logo
        Text(
            text = "বর্তমান লোগো প্রিভিউ:",
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(CyberBlack)
                .border(1.5.dp, NeonGreen, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (logoUrl.isNotBlank()) {
                AsyncImage(
                    model = logoUrl,
                    contentDescription = "Logo",
                    modifier = Modifier.size(64.dp),
                    contentScale = ContentScale.Crop
                )
            } else {
                Image(
                    painter = painterResource(id = R.drawable.ic_ninewickets_logo),
                    contentDescription = "Default Crest Logo",
                    modifier = Modifier.size(64.dp),
                    contentScale = ContentScale.Crop
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = logoUrl,
            onValueChange = { logoUrl = it },
            label = { Text("লোগো ইমেজ URL (খালি রাখলে ডিফল্ট ক্রেস্ট দেখাবে)") },
            placeholder = { Text("https://example.com/logo.png") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        CyberButton(
            text = "ব্যানার ও লোগো সংরক্ষণ করুন",
            onClick = { onSave(bannerUrl, logoUrl) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// 6. Homepage & Branding Settings Tab
@Composable
private fun HomepageSettingsTab(
    siteConfig: SiteConfig,
    onSave: (String, String, String, String) -> Unit
) {
    var brandName by remember(siteConfig) { mutableStateOf(siteConfig.brandName) }
    var adminName by remember(siteConfig) { mutableStateOf(siteConfig.adminDisplayName) }
    var announcement by remember(siteConfig) { mutableStateOf(siteConfig.announcementText) }
    var footer by remember(siteConfig) { mutableStateOf(siteConfig.footerText) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "হোমপেজ ও ব্র্যান্ডিং তথ্য",
            color = NeonGreenBright,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = brandName,
            onValueChange = { brandName = it },
            label = { Text("ব্র্যান্ডের নাম (Brand Name)") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_brand_name_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = adminName,
            onValueChange = { adminName = it },
            label = { Text("এডমিন প্রদর্শন নাম (Admin Display Name)") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_display_name_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = announcement,
            onValueChange = { announcement = it },
            label = { Text("হেডার ঘোষণা বা নোটিশ (Ticker Announcement)") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_announcement_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = footer,
            onValueChange = { footer = it },
            label = { Text("ফুটার টেক্সট ও কপিরাইট (Footer Text)") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("admin_footer_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        CyberButton(
            text = "হোমপেজ সেটিংস সংরক্ষণ করুন",
            onClick = { onSave(brandName, adminName, announcement, footer) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// 7. Account Settings Tab
@Composable
private fun AccountTab(
    onChangeCredentials: suspend (String, String, String) -> Result<Unit>
) {
    var currentPassword by remember { mutableStateOf("") }
    var newUsername by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "এডমিন অ্যাকাউন্ট সিকিউরিটি সেটিংস",
            color = NeonGreenBright,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "নিরাপত্তার স্বার্থে বর্তমান পাসওয়ার্ড যাচাই সাপেক্ষে নতুন ইউজারনেম ও পাসওয়ার্ড পরিবর্তন করুন।",
            color = TextSecondary,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (message != null) {
            Surface(
                color = if (isError) CyberRed.copy(alpha = 0.15f) else NeonGreen.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isError) CyberRed else NeonGreen
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = message!!,
                    color = if (isError) Color(0xFFFF859E) else NeonGreenBright,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(10.dp)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        OutlinedTextField(
            value = currentPassword,
            onValueChange = { currentPassword = it },
            label = { Text("বর্তমান পাসওয়ার্ড (Current Password)") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = newUsername,
            onValueChange = { newUsername = it },
            label = { Text("নতুন ইউজারনেম (New Username)") },
            placeholder = { Text("যেমন: admin") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = newPassword,
            onValueChange = { newPassword = it },
            label = { Text("নতুন পাসওয়ার্ড (New Password)") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("নতুন পাসওয়ার্ড নিশ্চিত করুন (Confirm Password)") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF283B31),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        CyberButton(
            text = "পাসওয়ার্ড আপডেট করুন",
            onClick = {
                if (currentPassword.isBlank()) {
                    message = "বর্তমান পাসওয়ার্ড প্রদান করুন。"
                    isError = true
                    return@CyberButton
                }
                if (newPassword.isNotBlank() && newPassword != confirmPassword) {
                    message = "নতুন পাসওয়ার্ডের দুটি ঘর মেলেনি।"
                    isError = true
                    return@CyberButton
                }
                coroutineScope.launch {
                    val res = onChangeCredentials(
                        currentPassword,
                        if (newUsername.isNotBlank()) newUsername else "admin",
                        newPassword
                    )
                    if (res.isSuccess) {
                        message = "এডমিন লগইন তথ্য সফলভাবে হালনাগাদ হয়েছে!"
                        isError = false
                        currentPassword = ""
                        newPassword = ""
                        confirmPassword = ""
                    } else {
                        message = res.exceptionOrNull()?.message ?: "ত্রুটি হয়েছে।"
                        isError = true
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// 8. Firebase Cloud Integration Guide Tab
@Composable
private fun FirebaseGuideTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "ফায়ারবেস ক্লাউড আর্কিটেকচার ও রুলস গাইড",
            color = NeonGreenBright,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "9WICKETS অ্যাপের জন্য ক্লাউড ফায়ারস্টোর ডাটাবেজ স্ট্রাকচার এবং সিকিউরিটি রুলস নিচে দেওয়া হলো।",
            color = TextSecondary,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        CyberCard(
            modifier = Modifier.fillMaxWidth(),
            glowColor = CyberCyan
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "প্রস্তাবিত ক্লাউড কালেকশন স্কিমা:",
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• /sites/{siteId}\n  - name, category, description, url, iconType, active, displayOrder\n\n• /agents/{agentId}\n  - name, category, phone, whatsappUrl, telegramUrl, active, displayOrder\n\n• /settings/{settingKey}\n  - brandName, adminDisplayName, announcementText, footerText, supportUrl",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        CyberCard(
            modifier = Modifier.fillMaxWidth(),
            glowColor = CyberGold
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Firestore Zero-Trust Security Rules:",
                    color = CyberGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "rules_version = '2';\nservice cloud.firestore {\n  match /databases/{database}/documents {\n    match /sites/{site} {\n      allow read: if resource.data.active == true;\n      allow write: if request.auth != null && request.auth.token.admin == true;\n    }\n    match /agents/{agent} {\n      allow read: if resource.data.active == true;\n      allow write: if request.auth != null && request.auth.token.admin == true;\n    }\n    match /settings/{setting} {\n      allow read: if true;\n      allow write: if request.auth != null && request.auth.token.admin == true;\n    }\n  }\n}",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
