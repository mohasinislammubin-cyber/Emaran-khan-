package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 9WICKETS Cyber Gaming Palette
val CyberBlack = Color(0xFF070A09)
val CyberDarkSurface = Color(0xFF0E1412)
val CyberCardBg = Color(0xFF131C18)
val CyberCardElevated = Color(0xFF1A2621)

val NeonGreen = Color(0xFF00FF66)
val NeonGreenBright = Color(0xFF39FF14)
val NeonGreenDark = Color(0xFF00B344)
val NeonGreenDim = Color(0xFF0D3322)
val NeonGreenBorder = Color(0xFF00E65B)

val CyberCyan = Color(0xFF00F0FF)
val CyberGold = Color(0xFFFFD700)
val CyberPurple = Color(0xFFB537F2)
val CyberRed = Color(0xFFFF3366)

val TextPrimary = Color(0xFFF5FFF8)
val TextSecondary = Color(0xFFA1B5AA)
val TextMuted = Color(0xFF6C8075)
val GlowGreen = Color(0x3300FF66)
