package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CyberColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = Color(0xFF00210A),
    primaryContainer = NeonGreenDim,
    onPrimaryContainer = NeonGreenBright,
    secondary = CyberCyan,
    onSecondary = Color(0xFF002026),
    secondaryContainer = Color(0xFF003840),
    onSecondaryContainer = Color(0xFF99F5FF),
    tertiary = CyberGold,
    onTertiary = Color(0xFF261D00),
    background = CyberBlack,
    onBackground = TextPrimary,
    surface = CyberDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberCardBg,
    onSurfaceVariant = TextSecondary,
    outline = NeonGreenBorder,
    outlineVariant = Color(0xFF1E3328),
    error = CyberRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Always enforce the signature 9WICKETS Cyber Neon aesthetic
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CyberColorScheme,
        typography = Typography,
        content = content
    )
}
