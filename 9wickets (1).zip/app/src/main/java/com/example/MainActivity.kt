package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AdminLoginScreen
import com.example.ui.screens.AgentListScreen
import com.example.ui.screens.AgentManageDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SiteManageDialog
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.NineWicketsViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    private val viewModel: NineWicketsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainApp(viewModel: NineWicketsViewModel) {
    val snackbarHostState = remember { SnackbarHostState() }

    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val currentAdminTab by viewModel.currentAdminTab.collectAsStateWithLifecycle()

    val siteConfig by viewModel.siteConfig.collectAsStateWithLifecycle()
    val activeSites by viewModel.activeSites.collectAsStateWithLifecycle()
    val allSites by viewModel.allSites.collectAsStateWithLifecycle()

    val filteredActiveAgents by viewModel.filteredActiveAgents.collectAsStateWithLifecycle()
    val allAgents by viewModel.allAgents.collectAsStateWithLifecycle()
    val activeAgentsCount by viewModel.activeAgentsCount.collectAsStateWithLifecycle()

    val totalSitesCount by viewModel.totalSitesCount.collectAsStateWithLifecycle()
    val activeSitesCount by viewModel.activeSitesCount.collectAsStateWithLifecycle()
    val totalAgentsCount by viewModel.totalAgentsCount.collectAsStateWithLifecycle()

    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsStateWithLifecycle()

    val searchQuery by viewModel.agentSearchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedAgentCategory.collectAsStateWithLifecycle()

    val showSiteDialog by viewModel.showSiteDialog.collectAsStateWithLifecycle()
    val editingSite by viewModel.editingSite.collectAsStateWithLifecycle()

    val showAgentDialog by viewModel.showAgentDialog.collectAsStateWithLifecycle()
    val editingAgent by viewModel.editingAgent.collectAsStateWithLifecycle()

    // Listen to snackbar feedback messages
    LaunchedEffect(Unit) {
        viewModel.snackbarMessage.collectLatest { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    // Handle system back button for secondary screens
    if (currentScreen != AppScreen.HOME) {
        BackHandler {
            viewModel.navigateTo(AppScreen.HOME)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> {
                    HomeScreen(
                        siteConfig = siteConfig,
                        activeSites = activeSites,
                        activeAgentsCount = activeAgentsCount,
                        isAdminLoggedIn = isAdminLoggedIn,
                        onNavigateToAgents = { viewModel.navigateTo(AppScreen.AGENTS) },
                        onAdminClick = {
                            if (isAdminLoggedIn) {
                                viewModel.navigateTo(AppScreen.ADMIN_DASHBOARD)
                            } else {
                                viewModel.navigateTo(AppScreen.ADMIN_LOGIN)
                            }
                        }
                    )
                }

                AppScreen.AGENTS -> {
                    AgentListScreen(
                        agents = filteredActiveAgents,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { viewModel.setAgentSearchQuery(it) },
                        selectedCategory = selectedCategory,
                        onCategorySelect = { viewModel.setAgentCategory(it) },
                        onBackClick = { viewModel.navigateTo(AppScreen.HOME) }
                    )
                }

                AppScreen.ADMIN_LOGIN -> {
                    AdminLoginScreen(
                        onLoginSubmit = { user, pass -> viewModel.login(user, pass) },
                        onBackClick = { viewModel.navigateTo(AppScreen.HOME) }
                    )
                }

                AppScreen.ADMIN_DASHBOARD -> {
                    AdminDashboardScreen(
                        currentTab = currentAdminTab,
                        onTabSelected = { viewModel.setAdminTab(it) },
                        siteConfig = siteConfig,
                        sites = allSites,
                        agents = allAgents,
                        totalSitesCount = totalSitesCount,
                        activeSitesCount = activeSitesCount,
                        totalAgentsCount = totalAgentsCount,
                        activeAgentsCount = activeAgentsCount,
                        onAddSiteClick = { viewModel.openNewSiteDialog() },
                        onEditSiteClick = { viewModel.openEditSiteDialog(it) },
                        onDeleteSiteClick = { viewModel.deleteSite(it) },
                        onToggleSiteStatus = { viewModel.toggleSiteStatus(it) },
                        onAddAgentClick = { viewModel.openNewAgentDialog() },
                        onEditAgentClick = { viewModel.openEditAgentDialog(it) },
                        onDeleteAgentClick = { viewModel.deleteAgent(it) },
                        onToggleAgentStatus = { viewModel.toggleAgentStatus(it) },
                        onUpdateContacts = { w, t, f, fg, s -> viewModel.updateContactSettings(w, t, f, fg, s) },
                        onUpdateBranding = { b, a, an, ft -> viewModel.updateBrandingSettings(b, a, an, ft) },
                        onUpdateBannerLogo = { bn, lg -> viewModel.updateBannerLogoSettings(bn, lg) },
                        onChangeCredentials = { cur, usr, pass -> viewModel.changeCredentials(cur, usr, pass) },
                        onPreviewHome = { viewModel.navigateTo(AppScreen.HOME) },
                        onLogout = { viewModel.logout() }
                    )
                }
            }

            // Dialog for Add/Edit Website
            if (showSiteDialog) {
                SiteManageDialog(
                    siteToEdit = editingSite,
                    onSave = { viewModel.saveSite(it) },
                    onDelete = if (editingSite != null) { { viewModel.deleteSite(it) } } else null,
                    onDismiss = { viewModel.closeSiteDialog() }
                )
            }

            // Dialog for Add/Edit Agent
            if (showAgentDialog) {
                AgentManageDialog(
                    agentToEdit = editingAgent,
                    onSave = { viewModel.saveAgent(it) },
                    onDelete = if (editingAgent != null) { { viewModel.deleteAgent(it) } } else null,
                    onDismiss = { viewModel.closeAgentDialog() }
                )
            }
        }
    }
}
