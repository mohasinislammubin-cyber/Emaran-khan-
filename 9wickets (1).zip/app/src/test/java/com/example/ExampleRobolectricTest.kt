package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.SecurityUtil
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `verify 9WICKETS app name in string resources`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("9WICKETS", appName)
  }

  @Test
  fun `verify secure sha256 password hashing and validation`() {
    val password = "Admin146"
    val hash = SecurityUtil.hashPassword(password)
    assertTrue(SecurityUtil.verifyPassword(password, hash))
    assertFalse(SecurityUtil.verifyPassword("wrongpass", hash))
  }
}
