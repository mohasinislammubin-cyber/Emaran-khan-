# 9WICKETS PREMIUM WEB & MOBILE PORTAL

## 1. Overview & Architecture
**9WICKETS** is a high-performance cyber gaming portal built with Kotlin and Jetpack Compose for Android. It manages dynamic website links, verified agent directories, customer support contacts, and secure administrative controls with an on-device persistent database (Room / SQLite) and Firebase Firestore compatibility.

- **Theme**: Premium Cyber Gaming (Black `#070A09` & Neon Green `#00FF66`, cyan highlights, glowing borders)
- **Admin**: EMRAN KHAN
- **Persistence**: Real on-device Room SQLite database preloaded with initial seed data, surviving app restarts and device reboots.

---

## 2. Hidden Admin Access & Authentication
- **Secret Access Trigger**: Tapping the "এডমিন" button in the top header **5 times consecutively** within 2.5 seconds unlocks the secret Admin Login interface. Casual taps by visitors will not open the interface.
- **Secret Username**: `Admin146`
- **Secret Password**: `Admin146`
- **Security**: Passwords are cryptographically hashed using SHA-256 with constant-time equality checks. Credentials can be modified anytime from the **অ্যাকাউন্ট** tab in the Admin Dashboard.

---

## 3. Database Schema

### `sites` Table / Collection
| Field | Type | Description |
|---|---|---|
| `id` | Long (PK) | Unique site identifier |
| `name` | String | Website title (e.g., "DOLLAR SITE", "বাংলা সাইট") |
| `category` | String | Category ("dollar", "bangla", "other") |
| `description`| String | Short subtitle or description |
| `url` | String | Web destination URL (validated http/https) |
| `iconType` | String | Icon identifier ("dollar", "bangla", "globe", "users", "sports", "casino") |
| `displayOrder` | Int | Sorting order |
| `active` | Boolean | Whether visible to public visitors |

### `agents` Table / Collection
| Field | Type | Description |
|---|---|---|
| `id` | Long (PK) | Unique agent identifier |
| `name` | String | Agent name |
| `category` | String | "Admin", "Sub Admin", "Super Agent", "Master Agent" |
| `phone` | String | Contact phone number (direct dialer) |
| `whatsappUrl`| String | WhatsApp chat link (`https://wa.me/...`) |
| `telegramUrl`| String | Telegram profile link (`https://t.me/...`) |
| `profileImageUrl` | String | Optional profile avatar URL |
| `displayOrder` | Int | Sorting order |
| `active` | Boolean | Whether active in directory |

### `app_settings` Table / Collection
Key-value configuration for brand name, admin display name, marquee announcement, banner, logo, and social support links.

---

## 4. Firebase Firestore Zero-Trust Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Public visitors can only view active sites
    match /sites/{siteId} {
      allow read: if resource.data.active == true;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }

    // Public visitors can only view active agents
    match /agents/{agentId} {
      allow read: if resource.data.active == true;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }

    // Public settings (brand name, header banner, support links)
    match /settings/{settingKey} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }

    // Admin users collection
    match /adminUsers/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

---

## 5. Key Features & How to Test

1. **Homepage Main Cards**:
   - **DOLLAR SITE**: Click to open dollar web portal.
   - **বাংলা সাইট**: Click to open Bengali web portal.
   - **এজেন্ট লিস্ট**: Click to navigate to the agent directory.
   - If a URL is empty, displays friendly Bengali notice: *"এই সাইটের লিংক এখনো যোগ করা হয়নি।"*
2. **Dynamic Site Management**:
   - Log in to the Admin Dashboard (`admin` / `admin123`).
   - Go to the **ওয়েবসাইট** tab, click **+ নতুন সাইট যোগ**, fill in name and URL.
   - Switch back to the homepage (preview button) to verify the new website card automatically appears!
3. **Agent Management**:
   - Filter by category ("Admin", "Sub Admin", "Super Agent", "Master Agent").
   - Search by name or phone number.
   - One-tap buttons for Call, WhatsApp, and Telegram.
4. **24/7 Floating Support Button**:
   - Fixed to the bottom-right corner of the screen with a pulsing neon green glow.
   - Tapping it opens the configured customer support destination.
